/** @type {import('next').NextConfig} */
const nextConfig = {
  // Server build for Vercel (API routes enabled). Do NOT set output:'export' here.
};
export default nextConfig;
